﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Uniteam.Models
{
    public class Onboarding_Register
    {
        public int ID { get; set; }

        [Required(ErrorMessage = "Please enter your full name.")]
        [MaxLength(50)]
        [RegularExpression("^[a-zA-Z_ ]*$", ErrorMessage = "Please enter valid name.")]
        public string FullName { get; set; }


        [Required(ErrorMessage = "Please enter your email address.")]
        [MaxLength(50)]
        [RegularExpression(@"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$", ErrorMessage = "Please enter a valid email address.")]
        public string WorkEmail { get; set; }


        [Required(ErrorMessage = "Please enter your password.")]
        [MaxLength(50)]
        [RegularExpression(@"^(?=.*[A-Z])(?=.*[a-z])(?=.*[#$^+=!*@%&])(?=.*\d).{8,}$", ErrorMessage = "Password must be at least 8 characters in length with one upper case letter, one number (0-9), and a special character (!,@,#,$,%,^,&,*).")]
        public string Password { get; set; }
    }
}
