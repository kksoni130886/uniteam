﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Uniteam.Models
{
    public class OfficeTeams
    {
        public string Department { get; set; }
    }

    public class addofficeteam
    {
        public List<OfficeTeams> OfficeTeams { get; set; }
    }
}
