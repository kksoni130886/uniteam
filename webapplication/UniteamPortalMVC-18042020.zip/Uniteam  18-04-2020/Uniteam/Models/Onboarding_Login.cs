﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace Uniteam.Models
{
    public class Onboarding_Login
    {
        public int ID { get; set; }

        [Required(ErrorMessage ="*Please enter your email address.")]
        [RegularExpression("^[a-zA-Z0-9_\\.-]+@([a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,6}$", ErrorMessage = "Please enter a valid email address.")]
        [MaxLength(50)]
        [EmailAddress]
        public string Email { get; set; }
        [Required(ErrorMessage ="*Please enter your password")]
        [MaxLength(50)]
        public string Password { get; set; }
    }
}
