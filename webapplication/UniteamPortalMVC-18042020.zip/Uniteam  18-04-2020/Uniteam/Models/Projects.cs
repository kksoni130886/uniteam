﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Uniteam.Models
{
    public class Projects
    {
        public string Name { get; set; }
    }
}
