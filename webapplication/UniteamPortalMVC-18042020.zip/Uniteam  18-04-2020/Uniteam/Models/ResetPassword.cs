﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
namespace Uniteam.Models
{
    public class ResetPassword
    {
        public int ID { get; set; }
        [Required(ErrorMessage = "Please enter your email address.")]
        [MaxLength(50)]
        [RegularExpression("^[a-zA-Z0-9_\\.-]+@([a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,6}$", ErrorMessage = "Please enter a valid email address.")]
        public string email { get; set; }
        
        
    }
}
