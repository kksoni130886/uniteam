﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace Uniteam.Models
{
    public class NewPasswordModel
    {
        [Required(ErrorMessage = "Please enter your password.")]
        [MaxLength(50)]
        [RegularExpression(@"^(?=.*[A-Z])(?=.*[a-z])(?=.*[#$^+=!*@%&])(?=.*[#$^+=!*@%&])(?=.*\d).{8,}$", ErrorMessage = "Password should be atleast 8 characters, One Uppercase alphabet, symbol except space and number must be there in password.")]
        public string Password { get; set; }
        [Required(ErrorMessage = "Please Re-enter your password.")]
        [Compare("Password", ErrorMessage = "Password and Confirmation Password not match.")]
        public string Confirm_Password { get; set; }
    }
}
