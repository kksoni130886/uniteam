﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace Uniteam.Models
{
    public class AddMemberModel
    {
        public int ID { get; set; }

        [Required(ErrorMessage = "Please enter full name of member.")]
        [MaxLength(50)]
        [RegularExpression("^[a-zA-Z_ ]*$", ErrorMessage = "Special Symbol will not be allowed")]
        public string name { get; set; }

        [Required(ErrorMessage = "Please enter work email address of member.")]
        [MaxLength(50)]
        public string email { get; set; }
        [MaxLength(10)]
        [RegularExpression("^[0-9]{10}$",ErrorMessage = "Only numbers is allowed and Should be 10 digit valid number.")]
        public string Phone { get; set; }
        [MaxLength(50)]
        [RegularExpression("^[a-zA-Z_ ]*$", ErrorMessage = "Special Symbol will not be allowed")]
        public string Jobtitle { get; set; }
        public string HOD { get; set; }

        [Required(ErrorMessage = "Please select your TimeZone.")]
        public string TimeZone { get; set; }
    }
}
