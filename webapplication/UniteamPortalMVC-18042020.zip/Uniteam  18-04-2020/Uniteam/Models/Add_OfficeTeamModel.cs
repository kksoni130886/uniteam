﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace Uniteam.Models
{
    public class Add_OfficeTeamModel
    {
        public int ClientID { get; set; }
        public string Email { get; set; }

        [Required(ErrorMessage ="Please enter your TeamName.")]
        [MaxLength(50)]
        [RegularExpression("^[a-zA-Z_ ]*$", ErrorMessage = "Special Symbol will not be allowed.")]
        public string Teamname { get; set; }
    }
}
