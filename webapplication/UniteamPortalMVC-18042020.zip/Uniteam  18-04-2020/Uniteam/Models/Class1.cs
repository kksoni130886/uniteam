﻿using System;
using System.Security.Cryptography;
using System.Text;
using System.IO;
using System.Text.RegularExpressions;
using System.Net.Mime;
using System.Globalization;
using Microsoft.VisualBasic;
/// <summary>
/// Summary description for Class1
/// </summary>

public class Class1
{
   
    public Class1()
    {
        //
        // TODO: Add constructor logic here
        //
    }

    
    public string Encrypt(string clearText)
    {
        string EncryptionKey = "MAKV2SPBNI99212";
        byte[] clearBytes = Encoding.Unicode.GetBytes(clearText);
        using (Aes encryptor = Aes.Create())
        {
            Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(EncryptionKey, new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76 });
            encryptor.Key = pdb.GetBytes(32);
            encryptor.IV = pdb.GetBytes(16);
            using (MemoryStream ms = new MemoryStream())
            {
                using (CryptoStream cs = new CryptoStream(ms, encryptor.CreateEncryptor(), CryptoStreamMode.Write))
                {
                    cs.Write(clearBytes, 0, clearBytes.Length);
                    cs.Close();
                }
                clearText = Convert.ToBase64String(ms.ToArray());
            }
        }
        return clearText;
    }
    public string Decrypt(string cipherText)
    {
        string EncryptionKey = "MAKV2SPBNI99212";
        byte[] cipherBytes = Convert.FromBase64String(cipherText);
        using (Aes encryptor = Aes.Create())
        {
            Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(EncryptionKey, new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76 });
            encryptor.Key = pdb.GetBytes(32);
            encryptor.IV = pdb.GetBytes(16);
            using (MemoryStream ms = new MemoryStream())
            {
                using (CryptoStream cs = new CryptoStream(ms, encryptor.CreateDecryptor(), CryptoStreamMode.Write))
                {
                    cs.Write(cipherBytes, 0, cipherBytes.Length);
                    cs.Close();
                }
                cipherText = Encoding.Unicode.GetString(ms.ToArray());
            }
        }
        return cipherText;
    }
    public string GetEncryptActivationKey(string clearText,int KeyPair)
    {
        string EncryptionKey = "";
        if (KeyPair == 1)
            EncryptionKey = "MAKV2SPBNI99212";
        else if (KeyPair == 2)
            EncryptionKey = "NBLW3TQCOJ00323";
        else if (KeyPair == 3)
            EncryptionKey = "OCMX4URDPK11434";
        else if (KeyPair == 4)
            EncryptionKey = "PDNY5VSEQL22545";
        else if (KeyPair == 5)
            EncryptionKey = "QEOZ6WTFRM33656";
        else if (KeyPair == 6)
            EncryptionKey = "RFPA7XUGSN44767";
        else if (KeyPair == 7)
            EncryptionKey = "SGQB8YVHTO55878";


        byte[] clearBytes = Encoding.Unicode.GetBytes(clearText);
        using (Aes encryptor = Aes.Create())
        {
            Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(EncryptionKey, new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76 });
            encryptor.Key = pdb.GetBytes(32);
            encryptor.IV = pdb.GetBytes(16);
            using (MemoryStream ms = new MemoryStream())
            {
                using (CryptoStream cs = new CryptoStream(ms, encryptor.CreateEncryptor(), CryptoStreamMode.Write))
                {
                    cs.Write(clearBytes, 0, clearBytes.Length);
                    cs.Close();
                }
                clearText = Convert.ToBase64String(ms.ToArray());
            }
        }
        return clearText;
    }
    public string GetDecryptActivationKey(string cipherText, int KeyPair)
    {
        string EncryptionKey = "";
        if (KeyPair == 1)
            EncryptionKey = "MAKV2SPBNI99212";
        else if (KeyPair == 2)
            EncryptionKey = "NBLW3TQCOJ00323";
        else if (KeyPair == 3)
            EncryptionKey = "OCMX4URDPK11434";
        else if (KeyPair == 4)
            EncryptionKey = "PDNY5VSEQL22545";
        else if (KeyPair == 5)
            EncryptionKey = "QEOZ6WTFRM33656";
        else if (KeyPair == 6)
            EncryptionKey = "RFPA7XUGSN44767";
        else if (KeyPair == 7)
            EncryptionKey = "SGQB8YVHTO55878";

        byte[] cipherBytes = Convert.FromBase64String(cipherText);
        using (Aes encryptor = Aes.Create())
        {
            Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(EncryptionKey, new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76 });
            encryptor.Key = pdb.GetBytes(32);
            encryptor.IV = pdb.GetBytes(16);
            using (MemoryStream ms = new MemoryStream())
            {
                using (CryptoStream cs = new CryptoStream(ms, encryptor.CreateDecryptor(), CryptoStreamMode.Write))
                {
                    cs.Write(cipherBytes, 0, cipherBytes.Length);
                    cs.Close();
                }
                cipherText = Encoding.Unicode.GetString(ms.ToArray());
            }
        }
        return cipherText;
    }        
}
