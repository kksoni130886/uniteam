﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace Uniteam.Models
{
    public class OTPmodel
    {
        public int ID { get; set; }

        public string otp { get; set; }

        [Required(ErrorMessage = "Please Enter your otp.")] 
        [MaxLength(1,ErrorMessage ="only one digit is allow.")]
        [RegularExpression("^[0-9]*$",ErrorMessage = " Only Number should be allowed")]
        public string otp1 { get; set; }
        [Required(ErrorMessage = "Please Enter your otp.")]
        [MaxLength(1, ErrorMessage = "only one digit is allow.")]
        [RegularExpression("^[0-9]*$", ErrorMessage = " Only Number should be allowed")]
        public string otp2 { get; set; }
        [Required(ErrorMessage = "Please Enter your otp.")]
        [MaxLength(1, ErrorMessage = "only one digit is allow.")]
        [RegularExpression("^[0-9]*$", ErrorMessage = " Only Number should be allowed")]
        public string otp3 { get; set; }
        [Required(ErrorMessage = "Please Enter your otp.")]
        [MaxLength(1, ErrorMessage = "only one digit is allow.")]
        [RegularExpression("^[0-9]*$", ErrorMessage = " Only Number should be allowed")]
        public string otp4 { get; set; }
    }
}
