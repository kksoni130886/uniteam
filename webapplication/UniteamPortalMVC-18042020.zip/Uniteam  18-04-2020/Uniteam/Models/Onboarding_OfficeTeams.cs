﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Uniteam.Models
{
    public class Onboarding_OfficeTeams
    {
        public int ClientID { get; set; }
        public List<departmentList> departmentList { get; set; }
    }
    public class departmentList
    {

        public string name { get; set; }
        public bool selected { get; set; }


    }

}
