﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Uniteam.Models
{
    public class Onboarding_CompanyInfo
    { 
        public int ID { get; set; }

        [Required(ErrorMessage = "Please enter your company name.")]
        [MaxLength(50)]
        //[RegularExpression("^[a-zA-Z_ ]*$", ErrorMessage = "Special Symbol will not be allowed.")]
        public string CompanyName { get; set; }
        [MaxLength(50)]
        //[RegularExpression("^[a-zA-Z_ ]*$", ErrorMessage = "Special Symbol will not be allowed.")]
        public string JobTitle { get; set; }
    }
}
