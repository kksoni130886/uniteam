﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using RestSharp;
using Uniteam.Models;
using Uniteam.Response;

namespace Uniteam.Controllers
{
    public class OnboardingController : Controller
    {
        Class1 obj = new Class1();
        private readonly IConfiguration _config;
        private readonly ILogger<OnboardingController> _logger;
        public OnboardingController(IConfiguration config, ILogger<OnboardingController> logger)
        {
            _config = config;
            _logger = logger;
        }
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult AccessToken()
        {
            try
            {
                string access_token = "";
                string token_type = "";
                string ClientID = _config.GetValue<string>("Authentication:ClientID");
                string ClientSecret = _config.GetValue<string>("Authentication:ClientSecret");

                bool jsonflag = false;
                string APIBaseURL = _config.GetValue<string>("ApiBaseUrl:IdentityURL");
                string apiendpoint = APIBaseURL + "authorize";
                var httpWebRequest = (HttpWebRequest)WebRequest.Create(apiendpoint);
                httpWebRequest.ContentType = "application/json";
                httpWebRequest.Method = "POST";
                using (var streamWriter = new StreamWriter(httpWebRequest.GetRequestStream()))
                {
                    string json = "{\"identityserver_url\":\"" + "http://appis.uniteam.io" + "\"," +
                        "\"client_id\":\"" + ClientID + "\"," +
                        "\"client_secret\":\"" + ClientSecret + "\"," +
                         "\"ip_address\":\"" + "" + "\"}";

                    streamWriter.Write(json);
                }
                var httpResponse = (HttpWebResponse)httpWebRequest.GetResponse();
                var Result = "";
                using (var streamReader = new StreamReader(httpResponse.GetResponseStream()))
                {
                    Result = streamReader.ReadToEnd();
                    jsonflag = true;
                }
                if (jsonflag)
                {
                    var json = JsonConvert.DeserializeObject<response_Authentication>(Result);
                    access_token = json.access_token;
                    token_type = json.token_type;
                    HttpContext.Session.SetString("clientaccesstoken", access_token);
                }
            }
            catch (WebException wex)
            {
                string StatusCode = ((HttpWebResponse)wex.Response).StatusCode.ToString();
                string StatusDescription = ((HttpWebResponse)wex.Response).StatusDescription;
                var error = "";
                if (wex.Response != null)
                {
                    using (var errorResponse = (HttpWebResponse)wex.Response)
                    {
                        using (var reader = new StreamReader(errorResponse.GetResponseStream()))
                        {
                            error = reader.ReadToEnd();
                            var msg = JsonConvert.DeserializeObject<Errormsg>(error);
                            var obj = msg.errors;
                            foreach (var jobj in obj)
                            {
                                ViewBag.msg = jobj.ToString();
                                return View();

                            }
                        }

                    }
                }
            }
            return View();
        }

        #region Login
        public IActionResult Login()
        {
            AccessToken();            
            return View();
        }

        [HttpPost]
        public IActionResult Login(Onboarding_Login data)
        {
            string identitytoken = HttpContext.Session.GetString("clientaccesstoken");
            string accessToken = "";
            string expiration = "";
            string refreshToken = "";
            string pass = obj.Encrypt(data.Password);
            bool jsonflag = false;
            try
            {


                string APIBaseURL = _config.GetValue<string>("ApiBaseUrl:LoginURL");
                string APIBaseURL1 = _config.GetValue<string>("ApiBaseUrl:Url");
                string apiendpoint = APIBaseURL + "login";
                var httpWebRequest = (HttpWebRequest)WebRequest.Create(apiendpoint);
                httpWebRequest.ContentType = "application/json";
                httpWebRequest.Method = "POST";
                using (var streamWriter = new StreamWriter(httpWebRequest.GetRequestStream()))
                {
                    string json1 = "{\"Email\":\"" + data.Email + "\"," +
                          "\"Password\":\"" + pass + "\"," +
                           "\"IdentityToken\":\"" + identitytoken + "\"}";
                    streamWriter.Write(json1);
                }
                var httpResponse = (HttpWebResponse)httpWebRequest.GetResponse();
                var Result = "";
                using (var streamReader = new StreamReader(httpResponse.GetResponseStream()))
                {
                    Result = streamReader.ReadToEnd();

                    jsonflag = true;
                }
                if (jsonflag)
                {
                    var d = JsonConvert.DeserializeObject<response_accessToken>(Result);
                    accessToken = d.accessToken;
                    expiration = Convert.ToString(d.expiration);
                    refreshToken = d.refreshToken;
                    HttpContext.Session.SetString("LoginToken", accessToken);
                }
                string apiendpoint1 = APIBaseURL1 + "users/profile?email=" + data.Email;
                var client = new RestClient(apiendpoint1);
                var request = new RestRequest(Method.GET);
                request.AddHeader("Authorization", "Bearer " + accessToken);
                //request.AddHeader("Content-Type", "application/json");
                IRestResponse response = client.Execute(request);
                var Result1 = response.Content;
                var json = JsonConvert.DeserializeObject<response_Profile>(Result1);
                if (json.portals.Count < 2)
                {
                    Portal obj = new Portal();
                    for (var i = 0; i < json.portals.Count; i++)
                    {
                        obj.clientID = json.portals[i].clientID;
                        string clientid = Convert.ToString(obj.clientID);
                        HttpContext.Session.SetString("LoginClientID", clientid);
                        obj.companyName = json.portals[i].companyName;
                        obj.role = json.portals[i].role;

                    }
                }
                HttpContext.Session.SetString("LoginEmail", json.email);
                HttpContext.Session.SetString("Loginname", json.fullName);

                if (json.userType == "Admin")
                {
                    if (json.signupFinished == "Yes")
                    {
                        if (json.portals.Count > 1)
                        {
                            return View("Portal", json);
                        }
                        else
                        {
                            return RedirectToAction("Home", "Onboarding");
                        }

                    }
                    else
                    {
                        if (json.companyCreated == "Yes")
                        {
                            if (json.officeTeamAdded == "Yes")
                            {
                                if (json.projectAdded == "Yes")
                                {
                                    if (json.portals.Count > 1)
                                    {
                                        return View("Portal", json);
                                    }
                                    else
                                    {

                                        return RedirectToAction("Home", "Onboarding");

                                    }
                                }
                                else
                                {
                                    return RedirectToAction("Projects", "Onboarding");
                                }

                            }
                            else
                            {
                                return RedirectToAction("OfficeTeams", "Onboarding");
                            }

                        }
                        else
                        {
                            return RedirectToAction("CompanyInfo", "Onboarding");
                        }
                    }
                }
                else if (json.userType == "Member")
                {
                    if (json.portals.Count > 1)
                    {
                        return View("Portal", json);
                    }
                    else
                    {
                        return RedirectToAction("Home", "Onboarding");
                    }
                }
                else
                {
                    return RedirectToAction("Register", "Onboarding");
                }
            }
            catch (WebException wex)
            {
                string StatusCode = ((HttpWebResponse)wex.Response).StatusCode.ToString();
                string StatusDescription = ((HttpWebResponse)wex.Response).StatusDescription;
                var error = "";
                if (wex.Response != null)
                {
                    using (var errorResponse = (HttpWebResponse)wex.Response)
                    {
                        using (var reader = new StreamReader(errorResponse.GetResponseStream()))
                        {
                            error = reader.ReadToEnd();
                            var msg = JsonConvert.DeserializeObject<Errormsg>(error);
                            var obj = msg.errors;
                            foreach (var jobj in obj)
                            {
                                ViewBag.msg = jobj.ToString();
                                return View("Login");
                            }
                        }

                    }
                }
            }
            return View();
        }
        #endregion

        #region ResetPassword
        public IActionResult Reset_Password()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Reset_Password(ResetPassword model)
        {
            HttpContext.Session.SetString("email_id", model.email);
            string identitytoken = HttpContext.Session.GetString("clientaccesstoken");
            try
            {

                bool jsonflag = false;
                string APIBaseURL = _config.GetValue<string>("ApiBaseUrl:Url");
                string apiendpoint = APIBaseURL + "users/resetpassword?action=getotp";
                var httpWebRequest = (HttpWebRequest)WebRequest.Create(apiendpoint);
                httpWebRequest.ContentType = "application/json";
                httpWebRequest.Method = "POST";
                using (var streamWriter = new StreamWriter(httpWebRequest.GetRequestStream()))
                {
                    string json1 = "{\"Email\":\"" + model.email + "\"," +
                                "\"IdentityToken\":\"" + identitytoken + "\"}";
                    streamWriter.Write(json1);
                }
                var httpResponse = (HttpWebResponse)httpWebRequest.GetResponse();
                var Result = "";
                using (var streamReader = new StreamReader(httpResponse.GetResponseStream()))
                {
                    Result = streamReader.ReadToEnd();

                    jsonflag = true;
                }
                if (jsonflag)
                {
                    var d = JsonConvert.DeserializeObject<response_resetpassword>(Result);
                    if (d.status == "Success")
                    {
                        HttpContext.Session.SetString("otp", d.otp);
                        return View("Otp");
                    }
                    else
                    {
                        return View();
                    }

                }
            }
            catch (Exception ex)
            {
                ViewBag.msg = "EmailID is not valid.";
                return View();
            }
            return View();
        }
        public IActionResult Otp()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Otp(OTPmodel model)
        {
            string APIBaseURL = _config.GetValue<string>("ApiBaseUrl:Url");
            string EmailID = HttpContext.Session.GetString("email_id");
            string identitytoken = HttpContext.Session.GetString("clientaccesstoken");
            try
            {
                model.otp = model.otp1 + model.otp2 + model.otp3 + model.otp4;
                bool jsonflag = false;

                string apiendpoint = APIBaseURL + "users/resetpassword?action=validateotp";
                var httpWebRequest = (HttpWebRequest)WebRequest.Create(apiendpoint);
                httpWebRequest.ContentType = "application/json";
                httpWebRequest.Method = "POST";
                using (var streamWriter = new StreamWriter(httpWebRequest.GetRequestStream()))
                {
                    string json1 = "{\"Email\":\"" + EmailID + "\"," +
                               "\"OTP\":" + model.otp + "," +
                                "\"IdentityToken\":\"" + identitytoken + "\"}";
                    streamWriter.Write(json1);
                }
                var httpResponse = (HttpWebResponse)httpWebRequest.GetResponse();
                var Result = "";
                using (var streamReader = new StreamReader(httpResponse.GetResponseStream()))
                {
                    Result = streamReader.ReadToEnd();

                    jsonflag = true;
                }
                if (jsonflag)
                {
                    var d = JsonConvert.DeserializeObject<response_otpverify>(Result);
                    if (d.status == "Success")
                    {
                        return RedirectToAction("NewPassword", "Onboarding");
                    }


                }
            }
            catch (WebException wex)
            {
                string StatusCode = ((HttpWebResponse)wex.Response).StatusCode.ToString();
                string StatusDescription = ((HttpWebResponse)wex.Response).StatusDescription;
                var error = "";
                if (wex.Response != null)
                {
                    using (var errorResponse = (HttpWebResponse)wex.Response)
                    {
                        using (var reader = new StreamReader(errorResponse.GetResponseStream()))
                        {
                            error = reader.ReadToEnd();
                            var msg = JsonConvert.DeserializeObject<Errormsg>(error);
                            var obj = msg.errors;
                            foreach (var jobj in obj)
                            {
                                ViewBag.msg = jobj.ToString();
                                return View();

                            }
                        }

                    }
                }
            }
            return View();
        }

        public IActionResult NewPassword()
        {
            return View();
        }

        [HttpPost]
        public IActionResult NewPassword(NewPasswordModel model)
        {
            string APIBaseURL = _config.GetValue<string>("ApiBaseUrl:Url");
            string EmailID = HttpContext.Session.GetString("email_id");
            string identitytoken = HttpContext.Session.GetString("clientaccesstoken");
            string pass = obj.Encrypt(model.Password);
            try
            {
                bool jsonflag = false;

                string apiendpoint = APIBaseURL + "users/resetpassword?action=changepassword";
                var httpWebRequest = (HttpWebRequest)WebRequest.Create(apiendpoint);
                httpWebRequest.ContentType = "application/json";
                httpWebRequest.Method = "POST";
                using (var streamWriter = new StreamWriter(httpWebRequest.GetRequestStream()))
                {
                    string json1 = "{\"Email\":\"" + EmailID + "\"," +
                               "\"NewPassword\":\"" + pass + "\"," +
                                "\"IdentityToken\":\"" + identitytoken + "\"}";
                    streamWriter.Write(json1);
                }
                var httpResponse = (HttpWebResponse)httpWebRequest.GetResponse();
                var Result = "";
                using (var streamReader = new StreamReader(httpResponse.GetResponseStream()))
                {
                    Result = streamReader.ReadToEnd();

                    jsonflag = true;
                }
                if (jsonflag)
                {
                    var d = JsonConvert.DeserializeObject<response_otpverify>(Result);
                    if (d.status == "Success")
                    {
                        return RedirectToAction("Confirmation", "Onboarding");
                    }
                    else
                    {
                        return View();
                    }
                }
            }
            catch (WebException wex)
            {
                string StatusCode = ((HttpWebResponse)wex.Response).StatusCode.ToString();
                string StatusDescription = ((HttpWebResponse)wex.Response).StatusDescription;
                var error = "";
                if (wex.Response != null)
                {
                    using (var errorResponse = (HttpWebResponse)wex.Response)
                    {
                        using (var reader = new StreamReader(errorResponse.GetResponseStream()))
                        {
                            error = reader.ReadToEnd();
                            var msg = JsonConvert.DeserializeObject<Errormsg>(error);
                            var obj = msg.errors;
                            foreach (var jobj in obj)
                            {
                                ViewBag.msg = jobj.ToString();
                                return View();
                            }
                        }

                    }
                }
            }
            return View();
        }

        public IActionResult Confirmation()
        {
            return View();
        }
        #endregion

        #region Register
        public IActionResult Register()
        {
            AccessToken();
            return View();
        }

        [HttpPost]
        public IActionResult Register(Onboarding_Register data)
        {
            string APIBaseURL = _config.GetValue<string>("ApiBaseUrl:LoginURL");
            string APIBaseURL1 = _config.GetValue<string>("ApiBaseUrl:Url");
            try
            {
                string identitytoken = HttpContext.Session.GetString("clientaccesstoken");
                string accessToken = "";
                string pass = obj.Encrypt(data.Password);
                bool jsonflag = false;
                //string APIBaseURL = System.Configuration.ConfigurationManager.AppSettings["APIBaseURL"];
                string apiendpoint = APIBaseURL + "register";
                var httpWebRequest = (HttpWebRequest)WebRequest.Create(apiendpoint);
                httpWebRequest.ContentType = "application/json";
                httpWebRequest.Method = "POST";
                using (var streamWriter = new StreamWriter(httpWebRequest.GetRequestStream()))
                {
                    string json1 = "{\"FullName\":\"" + data.FullName.Trim() + "\"," +
                        "\"Email\":\"" + data.WorkEmail + "\"," +
                          "\"Password\":\"" + pass + "\"," +
                          "\"SignupMode\":\"" + "Website" + "\"," +
                          "\"IdentityToken\":\"" + identitytoken + "\" }";

                    streamWriter.Write(json1);
                }

                var httpResponse = (HttpWebResponse)httpWebRequest.GetResponse();
                var Result = "";
                using (var streamReader = new StreamReader(httpResponse.GetResponseStream()))
                {
                    Result = streamReader.ReadToEnd();

                    jsonflag = true;
                }
                if (jsonflag)
                {

                    var dataitem = JsonConvert.DeserializeObject<response_accessToken>(Result);
                    accessToken = dataitem.accessToken;
                    HttpContext.Session.SetString("signup1token", accessToken);
                }

                string apiendpoint1 = APIBaseURL1 + "users/profile?email=" + data.WorkEmail;
                var client = new RestClient(apiendpoint1);
                var request = new RestRequest(Method.GET);
                request.AddHeader("Authorization", "Bearer " + accessToken);
                //request.AddHeader("Content-Type", "application/json");
                IRestResponse response = client.Execute(request);
                var Result1 = response.Content;
                string Response = response.Content;
                var json = JsonConvert.DeserializeObject<response_Profile>(Result1);
                if (json.portals.Count < 2)
                {
                    Portal obj = new Portal();
                    for (var i = 0; i < json.portals.Count; i++)
                    {
                        obj.clientID = json.portals[i].clientID;
                        string clientid = Convert.ToString(obj.clientID);
                        HttpContext.Session.SetString("SignUpClientID", clientid);
                        obj.companyName = json.portals[i].companyName;
                        obj.role = json.portals[i].role;
                    }
                }
                HttpContext.Session.SetString("SignupEmail", json.email);
                HttpContext.Session.SetString("Signupname", json.fullName);
                if (json.userType == "Admin")
                {
                    if (json.signupFinished == "Yes")
                    {
                        if (json.portals.Count > 1)
                        {
                            return View("Portal", json);
                        }
                        else
                        {
                            return RedirectToAction("Home", "Onboarding");
                        }

                    }
                    else
                    {
                        if (json.companyCreated == "Yes")
                        {
                            if (json.officeTeamAdded == "Yes")
                            {
                                if (json.projectAdded == "Yes")
                                {
                                    if (json.portals.Count > 1)
                                    {
                                        return View("Portal", json);
                                    }
                                    else
                                    {

                                        return RedirectToAction("Home", "Onboarding");

                                    }
                                }
                                else
                                {
                                    return RedirectToAction("Projects", "Onboarding");
                                }

                            }
                            else
                            {
                                return RedirectToAction("OfficeTeams", "Onboarding");
                            }

                        }
                        else
                        {
                            return RedirectToAction("CompanyInfo", "Onboarding");
                        }
                    }
                }
                else if (json.userType == "Member")
                {
                    if (json.portals.Count > 1)
                    {
                        return View("Portal", json);
                    }
                    else
                    {
                        return RedirectToAction("Home", "Onboarding");
                    }
                }
                else
                {
                    return RedirectToAction("Register", "Onboarding");
                }
            }
            catch (WebException wex)
            {
                string StatusCode = ((HttpWebResponse)wex.Response).StatusCode.ToString();
                string StatusDescription = ((HttpWebResponse)wex.Response).StatusDescription;
                var error = "";
                if (wex.Response != null)
                {
                    using (var errorResponse = (HttpWebResponse)wex.Response)
                    {
                        using (var reader = new StreamReader(errorResponse.GetResponseStream()))
                        {
                            error = reader.ReadToEnd();
                            var msg = JsonConvert.DeserializeObject<Errormsg>(error);
                            var obj = msg.errors;
                            foreach (var jobj in obj)
                            {
                                ViewBag.msg = jobj.ToString();
                                return View();
                            }
                        }

                    }
                }
            }
            return View();
        }

        public IActionResult CompanyInfo()
        {
            return View();
        }

        [HttpPost]
        public IActionResult CompanyInfo(Onboarding_CompanyInfo data)
        {
            string APIBaseURL = _config.GetValue<string>("ApiBaseUrl:Url");
            try
            {
                string Email = "";
                string Signup_Email = HttpContext.Session.GetString("SignupEmail");
                string Login_Email = HttpContext.Session.GetString("LoginEmail");
                string AccessToken = "";
                string Login_AccessToken = HttpContext.Session.GetString("LoginToken");
                string Signup_AccessToken = HttpContext.Session.GetString("signup1token");
                if (Signup_Email != null)
                {
                    Email = Signup_Email;
                }
                else
                {
                    Email = Login_Email;
                }

                if (Login_AccessToken != null)
                {
                    AccessToken = Login_AccessToken;
                }
                else
                {
                    AccessToken = Signup_AccessToken;
                }

                string apiendpoint = APIBaseURL + "onboarding/companyinfo";

                var client = new RestClient(apiendpoint);
                client.Timeout = -1;
                var request = new RestRequest(Method.POST);
                request.AddHeader("Authorization", "Bearer " + AccessToken);
                request.AddHeader("Content-Type", "application/json");
                request.AddParameter("application/json", "{\"Email\":\"" + Email + "\" ," +
                                 "\"CompanyName\":\"" + data.CompanyName.Trim() + "\"," +
                                 "\"JobTitle\":\"" + data.JobTitle + "\"}", ParameterType.RequestBody);
                IRestResponse response = client.Execute(request);
                var Response = response.Content;
                var json = JsonConvert.DeserializeObject<response_CompanyInfo>(Response);
                string clientid = Convert.ToString(json.clientID);
                HttpContext.Session.SetString("SignupClientID", clientid);
                if (json.status == "Success")
                {
                    return RedirectToAction("OfficeTeams", "Onboarding");
                }
                else
                {

                }
            }
            catch (WebException wex)
            {
                string StatusCode = ((HttpWebResponse)wex.Response).StatusCode.ToString();
                string StatusDescription = ((HttpWebResponse)wex.Response).StatusDescription;
                var error = "";
                if (wex.Response != null)
                {
                    using (var errorResponse = (HttpWebResponse)wex.Response)
                    {
                        using (var reader = new StreamReader(errorResponse.GetResponseStream()))
                        {
                            error = reader.ReadToEnd();
                            var msg = JsonConvert.DeserializeObject<Errormsg>(error);
                            var obj = msg.errors;
                            foreach (var jobj in obj)
                            {
                                ViewBag.msg = jobj.ToString();
                                return View();
                            }
                        }

                    }
                }
            }
            return View();
        }

        public IActionResult OfficeTeams()
        {
            string APIBaseURL = _config.GetValue<string>("ApiBaseUrl:Url");
            string AccessToken = "";
            string name = "";
            string Login_AccessToken = HttpContext.Session.GetString("LoginToken");
            string Signup_AccessToken = HttpContext.Session.GetString("signup1token");
            string Login_name = HttpContext.Session.GetString("Loginname");
            string Signup_name = HttpContext.Session.GetString("Signupname");
            if (Login_AccessToken != null)
            {
                AccessToken = Login_AccessToken;
            }
            else
            {
                AccessToken = Signup_AccessToken;
            }
            if (Login_name != null)
            {
                name = Login_name;
            }
            else
            {
                name = Signup_name;
            }
            try
            {
                Onboarding_OfficeTeams mainlist = new Onboarding_OfficeTeams();

                string apiendpoint = APIBaseURL + "masterlist";
                var client = new RestClient(apiendpoint);
                var request = new RestRequest(Method.GET);
                request.AddHeader("Authorization", "Bearer " + AccessToken);
                //request.AddHeader("Content-Type", "application/json");
                IRestResponse response = client.Execute(request);
                var Result = response.Content;

                var json = JsonConvert.DeserializeObject<Onboarding_OfficeTeams>(Result);
                mainlist.departmentList = json.departmentList;

                return View(mainlist);
            }
            catch (Exception ex)
            {
                ViewBag.msg = ex;
                return View("OfficeTeams");
            }
          
        }

        [HttpPost]
        public IActionResult OfficeTeams(Onboarding_OfficeTeams model)
        {
            string APIBaseURL = _config.GetValue<string>("ApiBaseUrl:Url");
            try
            {
                string AccessToken = "";
                string Email = "";
                List<OfficeTeams> Departments = new List<OfficeTeams>();

                for (int i = 0; i < model.departmentList.Count; i++)
                {
                    OfficeTeams obj = new OfficeTeams();
                    if (model.departmentList[i].selected is true)
                    {
                        obj.Department = model.departmentList[i].name;
                        Departments.Add(obj);
                    }
                }

                var list = JsonConvert.SerializeObject(Departments);
                int ClientIDsignup = Convert.ToInt32(HttpContext.Session.GetString("SignupClientID"));
                int ClientIDlogin = Convert.ToInt32(HttpContext.Session.GetString("LoginClientID"));
                string Signup_Email = HttpContext.Session.GetString("SignupEmail");
                string Login_Email = HttpContext.Session.GetString("LoginEmail");
                string Login_AccessToken = HttpContext.Session.GetString("LoginToken");
                string Signup_AccessToken = HttpContext.Session.GetString("signup1token");
                if (ClientIDlogin != 0)
                {
                    model.ClientID = ClientIDlogin;
                }
                else
                {
                    model.ClientID = ClientIDsignup;
                }
                if (Signup_Email != null)
                {
                    Email = Signup_Email;
                }
                else
                {
                    Email = Login_Email;
                }
                if (Login_AccessToken != null)
                {
                    AccessToken = Login_AccessToken;
                }
                else
                {
                    AccessToken = Signup_AccessToken;
                }

                if (Departments.Count != 0)
                {
                    string apiendpoint = APIBaseURL + "onboarding/officeteams";

                    var client = new RestClient(apiendpoint);
                    client.Timeout = -1;
                    var request = new RestRequest(Method.POST);
                    request.AddHeader("Authorization", "Bearer " + AccessToken);
                    request.AddHeader("Content-Type", "application/json");
                    request.AddParameter("application/json", "{\"Email\":\"" + Email + "\" ," +
                                     "\"ClientID\":" + model.ClientID + "," +
                                     "\"OfficeTeams\":" +
                                     list
                                     + "}", ParameterType.RequestBody);
                    IRestResponse response = client.Execute(request);
                    var Response = response.Content;
                    var json = JsonConvert.DeserializeObject<response_OfficeTeams>(Response);

                    if (json.status == "Success")
                    {
                        return RedirectToAction("Projects", "Onboarding");
                    }
                }
                else
                {
                    return RedirectToAction("Projects", "Onboarding");
                }
            }
            catch (WebException wex)
            {
                string StatusCode = ((HttpWebResponse)wex.Response).StatusCode.ToString();
                string StatusDescription = ((HttpWebResponse)wex.Response).StatusDescription;
                var error = "";
                if (wex.Response != null)
                {
                    using (var errorResponse = (HttpWebResponse)wex.Response)
                    {
                        using (var reader = new StreamReader(errorResponse.GetResponseStream()))
                        {
                            error = reader.ReadToEnd();
                            var msg = JsonConvert.DeserializeObject<Errormsg>(error);
                            var obj = msg.errors;
                            foreach (var jobj in obj)
                            {
                                ViewBag.msg = jobj.ToString();
                                return View();
                            }
                        }

                    }
                }
            }
            return View();
        }

        public IActionResult Projects()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Projects(string[] project)
        {
            string APIBaseURL = _config.GetValue<string>("ApiBaseUrl:Url");
            try
            {
                int ClientID;
                //int ClientIDlogin;
                string AccessToken = "";
                string Email = "";
                string array = "";
                List<Projects> projects = new List<Projects>();
                for (var i = 0; i < project.Length; i++)
                {
                    Projects obj = new Projects();
                    obj.Name = project[i];
                    if (obj.Name == null)
                    {
                        array = "";
                    }
                    else
                    {
                        array = obj.Name;
                    }
                    projects.Add(obj);
                }
                var list = JsonConvert.SerializeObject(projects);
                int ClientIDsignup = Convert.ToInt32(HttpContext.Session.GetString("SignupClientID"));
                int ClientIDlogin = Convert.ToInt32(HttpContext.Session.GetString("LoginClientID"));

                string Signup_Email = HttpContext.Session.GetString("SignupEmail");
                string Login_Email = HttpContext.Session.GetString("LoginEmail");
                string Login_AccessToken = HttpContext.Session.GetString("LoginToken");
                string Signup_AccessToken = HttpContext.Session.GetString("signup1token");
                if (ClientIDlogin != 0)
                {
                    ClientID = ClientIDlogin;
                }
                else
                {
                    ClientID = ClientIDsignup;
                }
                if (Signup_Email != null)
                {
                    Email = Signup_Email;
                }
                else
                {
                    Email = Login_Email;
                }
                if (Login_AccessToken != null)
                {
                    AccessToken = Login_AccessToken;
                }
                else
                {
                    AccessToken = Signup_AccessToken;
                }

                if (array == "")
                {

                }
                else
                {
                    string apiendpoint = APIBaseURL + "onboarding/projects";

                    var client = new RestClient(apiendpoint);
                    client.Timeout = -1;
                    var request = new RestRequest(Method.POST);
                    request.AddHeader("Authorization", "Bearer " + AccessToken);
                    request.AddHeader("Content-Type", "application/json");
                    request.AddParameter("application/json", "{\"Email\":\"" + Email + "\" ," +
                                     "\"ClientID\":" + ClientID + "," +
                                     "\"Projects\":" +
                                     list
                                     + "}", ParameterType.RequestBody);
                    IRestResponse response = client.Execute(request);
                    var Response = response.Content;
                    var json = JsonConvert.DeserializeObject<response_Projects>(Response);

                }
                string apiendpoint1 = APIBaseURL + "onboarding/finish";

                var client1 = new RestClient(apiendpoint1);
                client1.Timeout = -1;
                var request1 = new RestRequest(Method.POST);
                request1.AddHeader("Authorization", "Bearer " + AccessToken);
                request1.AddHeader("Content-Type", "application/json");
                request1.AddParameter("application/json", "{\"Email\":\"" + Email + "\"}", ParameterType.RequestBody);
                IRestResponse response1 = client1.Execute(request1);
                var Response1 = response1.Content;
                var json1 = JsonConvert.DeserializeObject<response_finishonboarding>(Response1);
                return RedirectToAction("Home", "Onboarding");
            }
            catch (WebException wex)
            {
                string StatusCode = ((HttpWebResponse)wex.Response).StatusCode.ToString();
                string StatusDescription = ((HttpWebResponse)wex.Response).StatusDescription;
                var error = "";
                if (wex.Response != null)
                {
                    using (var errorResponse = (HttpWebResponse)wex.Response)
                    {
                        using (var reader = new StreamReader(errorResponse.GetResponseStream()))
                        {
                            error = reader.ReadToEnd();
                            var msg = JsonConvert.DeserializeObject<Errormsg>(error);
                            var obj = msg.errors;
                            foreach (var jobj in obj)
                            {
                                ViewBag.msg = jobj.ToString();
                                return View();
                            }
                        }
                    }
                }
            }
            return View();
        }
        #endregion

        #region Portal
        public IActionResult Portal()
        {
            return View();
        }
        #endregion

        #region Home
        public IActionResult Home(int id)
        {
            try
            {
                HttpContext.Session.SetInt32("ID", id);
                string ClientID = "";
                string Email = "";
                string Signup_Email = HttpContext.Session.GetString("SignupEmail");
                string Login_Email = HttpContext.Session.GetString("LoginEmail");
                string AccessToken = "";
                string Login_AccessToken = HttpContext.Session.GetString("LoginToken");
                string Signup_AccessToken = HttpContext.Session.GetString("signup1token");
                string ClientIDsignup = HttpContext.Session.GetString("SignUpClientID");
                string ClientIDlogin = HttpContext.Session.GetString("LoginClientID");
                if (Signup_Email != null)
                {
                    Email = Signup_Email;
                }
                else
                {
                    Email = Login_Email;
                }

                if (Login_AccessToken != null)
                {
                    AccessToken = Login_AccessToken;
                }
                else
                {
                    AccessToken = Signup_AccessToken;
                }
                if (ClientIDlogin != null)
                {
                    ClientID = ClientIDlogin;
                }
                else if (ClientIDsignup != null)
                {
                    ClientID = ClientIDsignup;
                }
                else if (id != 0)
                {
                    ClientID = Convert.ToString(id);
                }
               
                string apiendpoint = "http://api.uniteam.io/api/webhome?email=" + Email + "&clientid=" + ClientID;
                var client = new RestClient(apiendpoint);
                var request = new RestRequest(Method.GET);
                request.AddHeader("Authorization", "Bearer " + AccessToken);

                IRestResponse response = client.Execute(request);
                var Response = response.Content;
                var json = JsonConvert.DeserializeObject<response_Home>(Response);
                HttpContext.Session.SetString("UserName", json.fullName);
                HttpContext.Session.SetString("Email", json.email);
                HttpContext.Session.SetInt32("clientID", json.clientId);
                HttpContext.Session.SetString("CompanyName", json.companyName);
                return View(json);
            }
            catch (Exception ex)
            {

            }
            return View();
        }
        #endregion
    }

}