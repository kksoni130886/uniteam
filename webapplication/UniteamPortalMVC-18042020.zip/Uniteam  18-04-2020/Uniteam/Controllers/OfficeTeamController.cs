﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using RestSharp;
using Uniteam.Models;
using Uniteam.Response;

namespace Uniteam.Controllers
{
    public class OfficeTeamController : Controller
    {
        private readonly IConfiguration _config;
        public OfficeTeamController(IConfiguration config)
        {
            _config = config;

        }
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult OfficeTeam()
        {
            string APIBaseURL = _config.GetValue<string>("ApiBaseUrl:Url");
            try
            {
                string accessToken = "";
                string Login_AccessToken = HttpContext.Session.GetString("LoginToken");
                string Signup_AccessToken = HttpContext.Session.GetString("signup1token");
                string Email = HttpContext.Session.GetString("Email");
                int ClientID = Convert.ToInt32(HttpContext.Session.GetInt32("clientID"));
                if (Login_AccessToken != null)
                {
                    accessToken = Login_AccessToken;
                }
                else
                {
                    accessToken = Signup_AccessToken;
                }
                string apiendpoint1 = APIBaseURL + "officeteams/teamlist?email=" + Email + "&clientid=" + ClientID;
                var client = new RestClient(apiendpoint1);
                var request = new RestRequest(Method.GET);
                request.AddHeader("Authorization", "Bearer " + accessToken);
                //request.AddHeader("Content-Type", "application/json");
                IRestResponse response = client.Execute(request);
                var Result = response.Content;
                string Response = response.Content;

                var json = JsonConvert.DeserializeObject<response_Officeteamlist>(Result);
                return View(json);
            }
            catch (WebException wex)
            {
                string StatusCode = ((HttpWebResponse)wex.Response).StatusCode.ToString();
                string StatusDescription = ((HttpWebResponse)wex.Response).StatusDescription;
                var error = "";
                if (wex.Response != null)
                {
                    using (var errorResponse = (HttpWebResponse)wex.Response)
                    {
                        using (var reader = new StreamReader(errorResponse.GetResponseStream()))
                        {
                            error = reader.ReadToEnd();
                            var msg = JsonConvert.DeserializeObject<Errormsg>(error);
                            var obj = msg.errors;
                            foreach (var jobj in obj)
                            {
                                ViewBag.msg = jobj.ToString();
                                return View();
                            }
                        }
                    }
                }
            }
            return View();
        }

        [HttpPost]
        public IActionResult OfficeTeam(OfficeTeamlist model)
        {
            string APIBaseURL = _config.GetValue<string>("ApiBaseUrl:Url");
            string accessToken = "";
            string Login_AccessToken = HttpContext.Session.GetString("LoginToken");
            string Signup_AccessToken = HttpContext.Session.GetString("signup1token");
            string Email = HttpContext.Session.GetString("Email");
            int ClientID = Convert.ToInt32(HttpContext.Session.GetInt32("clientID"));
            int TeamID = model.teamid;
            if (Login_AccessToken != null)
            {
                accessToken = Login_AccessToken;
            }
            else
            {
                accessToken = Signup_AccessToken;
            }
            try
            {
                string apiendpoint = APIBaseURL + "officeteams/memberlist?email=" + Email + "&clientid=" + ClientID + "&teamid=" + TeamID + "&searchby=" + "" + "&searchvalue=" + "";
                var client = new RestClient(apiendpoint);
                var request = new RestRequest(Method.GET);
                request.AddHeader("Authorization", "Bearer " + accessToken);
                IRestResponse response = client.Execute(request);
                var Result1 = response.Content;
                var json = JsonConvert.DeserializeObject<response_memberlist>(Result1);

            }
            catch (WebException wex)
            {
                string StatusCode = ((HttpWebResponse)wex.Response).StatusCode.ToString();
                string StatusDescription = ((HttpWebResponse)wex.Response).StatusDescription;
                var error = "";
                if (wex.Response != null)
                {
                    using (var errorResponse = (HttpWebResponse)wex.Response)
                    {
                        using (var reader = new StreamReader(errorResponse.GetResponseStream()))
                        {
                            error = reader.ReadToEnd();
                            var msg = JsonConvert.DeserializeObject<Errormsg>(error);
                            var obj = msg.errors;
                            foreach (var jobj in obj)
                            {
                                ViewBag.msg = jobj.ToString();
                                return View();
                            }
                        }

                    }
                }
            }
            return View();
        }

        #region add Team
        public IActionResult Add_officeteam()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Add_officeteam(Add_OfficeTeamModel model)
        {
            if (ModelState.IsValid)
            {
                string APIBaseURL = _config.GetValue<string>("ApiBaseUrl:Url");
                string accessToken = "";
                string Login_AccessToken = HttpContext.Session.GetString("LoginToken");
                string Signup_AccessToken = HttpContext.Session.GetString("signup1token");
                model.Email = HttpContext.Session.GetString("Email");
                model.ClientID = Convert.ToInt32(HttpContext.Session.GetInt32("clientID"));
                if (Login_AccessToken != null)
                {
                    accessToken = Login_AccessToken;
                }
                else
                {
                    accessToken = Signup_AccessToken;
                }
                try
                {
                    string apiendpoint = APIBaseURL + "officeteams/addteam";
                    var client = new RestClient(apiendpoint);
                    var request = new RestRequest(Method.POST);
                    request.AddHeader("Authorization", "Bearer " + accessToken);
                    request.AddHeader("Content-Type", "application/json");
                    request.AddParameter("application/json", "{\"Email\":\"" + model.Email + "\" ," +
                                     "\"ClientID\":" + model.ClientID + "," +
                                     "\"TeamName\":\"" + model.Teamname.Trim() + "\"}", ParameterType.RequestBody);
                    IRestResponse response = client.Execute(request);
                    var Result1 = response.Content;
                    var json = JsonConvert.DeserializeObject<response_Addofficeteam>(Result1);
                    if (json.status == "Success")
                    {
                        return View("SuccessAddTeam", json);
                    }
                    else
                    {
                        return View();
                    }
                }
                catch (WebException wex)
                {
                    string StatusCode = ((HttpWebResponse)wex.Response).StatusCode.ToString();
                    string StatusDescription = ((HttpWebResponse)wex.Response).StatusDescription;
                    var error = "";
                    if (wex.Response != null)
                    {
                        using (var errorResponse = (HttpWebResponse)wex.Response)
                        {
                            using (var reader = new StreamReader(errorResponse.GetResponseStream()))
                            {
                                error = reader.ReadToEnd();
                                var msg = JsonConvert.DeserializeObject<Errormsg>(error);
                                var obj = msg.errors;
                                foreach (var jobj in obj)
                                {
                                    ViewBag.msg = jobj.ToString();
                                    return View();
                                }
                            }
                        }
                    }
                }
            }
            else
            {
                return View();
            }
            return View();
        }

        public IActionResult SuccessAddTeam()
        {
            return View();
        }
        #endregion

        #region Team Setting

        public IActionResult TeamSetting()
        {
            string APIBaseURL = _config.GetValue<string>("ApiBaseUrl:Url");
            string accessToken = "";
            string Login_AccessToken = HttpContext.Session.GetString("LoginToken");
            string Signup_AccessToken = HttpContext.Session.GetString("signup1token");
            string Email = HttpContext.Session.GetString("Email");
            int ClientID = Convert.ToInt32(HttpContext.Session.GetInt32("clientID"));
            int TeamID = 1;
            if (Login_AccessToken != null)
            {
                accessToken = Login_AccessToken;
            }
            else
            {
                accessToken = Signup_AccessToken;
            }
            try
            {


                string apiendpoint = APIBaseURL + "officeteams/teamsettings?email=" + Email + "&clientid=" + ClientID + "&teamid=" + TeamID;
                var client = new RestClient(apiendpoint);
                var request = new RestRequest(Method.GET);
                request.AddHeader("Authorization", "Bearer " + accessToken);
                IRestResponse response = client.Execute(request);
                var Result1 = response.Content;
                var json = JsonConvert.DeserializeObject<response_TeamSetting>(Result1);

            }
            catch (WebException wex)
            {
                string StatusCode = ((HttpWebResponse)wex.Response).StatusCode.ToString();
                string StatusDescription = ((HttpWebResponse)wex.Response).StatusDescription;
                var error = "";
                if (wex.Response != null)
                {
                    using (var errorResponse = (HttpWebResponse)wex.Response)
                    {
                        using (var reader = new StreamReader(errorResponse.GetResponseStream()))
                        {
                            error = reader.ReadToEnd();
                            var msg = JsonConvert.DeserializeObject<Errormsg>(error);
                            var obj = msg.errors;
                            foreach (var jobj in obj)
                            {
                                ViewBag.msg = jobj.ToString();
                                return View();
                            }
                        }

                    }
                }
            }
            return View();
        }

        [HttpPost]
        public IActionResult TeamSetting(response_TeamSetting model)
        {
            string APIBaseURL = _config.GetValue<string>("ApiBaseUrl:Url");
            string accessToken = "";
            string Login_AccessToken = HttpContext.Session.GetString("LoginToken");
            string Signup_AccessToken = HttpContext.Session.GetString("signup1token");
            string Email = HttpContext.Session.GetString("Email");
            int ClientID = Convert.ToInt32(HttpContext.Session.GetInt32("clientID"));
            if (Login_AccessToken != null)
            {
                accessToken = Login_AccessToken;
            }
            else
            {
                accessToken = Signup_AccessToken;
            }
            try
            {
                string apiendpoint = APIBaseURL + "officeteams/updateteam";
                var client = new RestClient(apiendpoint);
                var request = new RestRequest(Method.POST);
                request.AddHeader("Authorization", "Bearer " + accessToken);
                request.AddHeader("Content-Type", "application/json");
                request.AddParameter("application/json", "{\"Email\":\"" + model.Email + "\" ," +
                                 "\"ClientID\":" + model.ClientID + "," +
                                 "\"TeamID\":" + model.TeamID + "," +
                                 "\"TeamName\":\"" + model.TeamName + "\"," +
                                 "\"Description\":\"" + model.Description + "\"," +
                                 "\"TaskVisibility\":\"" + model.TaskVisibility + "\"," +
                                 "\"Reminder\":" + model.Reminder + "," +
                                 "\"ReminderTime\":\"" + model.ReminderTime + "\"," +
                                 "\"Digest\":" + model.Digest + "," +
                                 "\"DigestTime\":\"" + model.DigestTime + "\"}", ParameterType.RequestBody);
                IRestResponse response = client.Execute(request);
                var Result1 = response.Content;
                var json = JsonConvert.DeserializeObject<response_Addofficeteam>(Result1);

            }
            catch (WebException wex)
            {
                string StatusCode = ((HttpWebResponse)wex.Response).StatusCode.ToString();
                string StatusDescription = ((HttpWebResponse)wex.Response).StatusDescription;
                var error = "";
                if (wex.Response != null)
                {
                    using (var errorResponse = (HttpWebResponse)wex.Response)
                    {
                        using (var reader = new StreamReader(errorResponse.GetResponseStream()))
                        {
                            error = reader.ReadToEnd();
                            var msg = JsonConvert.DeserializeObject<Errormsg>(error);
                            var obj = msg.errors;
                            foreach (var jobj in obj)
                            {
                                ViewBag.msg = jobj.ToString();
                                return View();
                            }
                        }

                    }
                }
            }
            return View();
        }


        public IActionResult DeleteTeam()
        {
            string APIBaseURL = _config.GetValue<string>("ApiBaseUrl:Url");
            string accessToken = "";
            string Login_AccessToken = HttpContext.Session.GetString("LoginToken");
            string Signup_AccessToken = HttpContext.Session.GetString("signup1token");
            string Email = HttpContext.Session.GetString("Email");
            int ClientID = Convert.ToInt32(HttpContext.Session.GetInt32("clientID"));
            if (Login_AccessToken != null)
            {
                accessToken = Login_AccessToken;
            }
            else
            {
                accessToken = Signup_AccessToken;
            }
            try
            {


                string apiendpoint = APIBaseURL + "officeteams/deleteteam";
                var client = new RestClient(apiendpoint);
                var request = new RestRequest(Method.POST);
                request.AddHeader("Authorization", "Bearer " + accessToken);
                request.AddHeader("Content-Type", "application/json");
                request.AddParameter("application/json", "{\"Email\":\"" + Email + "\" ," +
                                 "\"ClientID\":" + ClientID + "," +
                                 "\"TeamID\":" + ClientID + "}", ParameterType.RequestBody);
                IRestResponse response = client.Execute(request);
                var Result1 = response.Content;
                var json = JsonConvert.DeserializeObject<response_Addofficeteam>(Result1);
                if (json.status == "Success")
                {
                    return View("SuccessAddTeam", json);
                }
                else
                {
                    return View();
                }
            }
            catch (WebException wex)
            {
                string StatusCode = ((HttpWebResponse)wex.Response).StatusCode.ToString();
                string StatusDescription = ((HttpWebResponse)wex.Response).StatusDescription;
                var error = "";
                if (wex.Response != null)
                {
                    using (var errorResponse = (HttpWebResponse)wex.Response)
                    {
                        using (var reader = new StreamReader(errorResponse.GetResponseStream()))
                        {
                            error = reader.ReadToEnd();
                            var msg = JsonConvert.DeserializeObject<Errormsg>(error);
                            var obj = msg.errors;
                            foreach (var jobj in obj)
                            {
                                ViewBag.msg = jobj.ToString();
                                return View();
                            }
                        }

                    }
                }
            }
            return View();
        }
        #endregion

        public IActionResult MemberList()
        {
            string APIBaseURL = _config.GetValue<string>("ApiBaseUrl:Url");
            string accessToken = "";
            string Login_AccessToken = HttpContext.Session.GetString("LoginToken");
            string Signup_AccessToken = HttpContext.Session.GetString("signup1token");
            string Email = HttpContext.Session.GetString("Email");
            int ClientID = Convert.ToInt32(HttpContext.Session.GetInt32("clientID"));
            int TeamID = 1;
            if (Login_AccessToken != null)
            {
                accessToken = Login_AccessToken;
            }
            else
            {
                accessToken = Signup_AccessToken;
            }
            try
            {
                string apiendpoint = APIBaseURL + "officeteams/memberlist?email=" + Email + "&clientid=" + ClientID + "&teamid=" + TeamID + "&searchby=" + "" + "&searchvalue=" + "";
                var client = new RestClient(apiendpoint);
                var request = new RestRequest(Method.GET);
                request.AddHeader("Authorization", "Bearer " + accessToken);
                IRestResponse response = client.Execute(request);
                var Result1 = response.Content;
                var json = JsonConvert.DeserializeObject<response_Addofficeteam>(Result1);
                if (json.status == "Success")
                {
                    return View("SuccessAddTeam", json);
                }
                else
                {
                    return View();
                }
            }
            catch (WebException wex)
            {
                string StatusCode = ((HttpWebResponse)wex.Response).StatusCode.ToString();
                string StatusDescription = ((HttpWebResponse)wex.Response).StatusDescription;
                var error = "";
                if (wex.Response != null)
                {
                    using (var errorResponse = (HttpWebResponse)wex.Response)
                    {
                        using (var reader = new StreamReader(errorResponse.GetResponseStream()))
                        {
                            error = reader.ReadToEnd();
                            var msg = JsonConvert.DeserializeObject<Errormsg>(error);
                            var obj = msg.errors;
                            foreach (var jobj in obj)
                            {
                                ViewBag.msg = jobj.ToString();
                                return View();
                            }
                        }

                    }
                }
            }
            return View();
        }

        #region Add Member
        public IActionResult AddMember()
        {
            return View();
        }

        [HttpPost]
        public IActionResult AddMember(AddMemberModel model)
        {
            if (ModelState.IsValid)
            {
                string APIBaseURL = _config.GetValue<string>("ApiBaseUrl:Url");
                string accessToken = "";
                string Login_AccessToken = HttpContext.Session.GetString("LoginToken");
                string Signup_AccessToken = HttpContext.Session.GetString("signup1token");
                var a = Convert.ToInt32(HttpContext.Session.GetInt32("clientID"));
                if (Login_AccessToken != null)
                {
                    accessToken = Login_AccessToken;
                }
                else
                {
                    accessToken = Signup_AccessToken;
                }
                try
                {
                    string apiendpoint = APIBaseURL + "officeteams/addmember";
                    var client = new RestClient(apiendpoint);
                    var request = new RestRequest(Method.POST);
                    request.AddHeader("Authorization", "Bearer " + accessToken);
                    request.AddHeader("Content-Type", "application/json");
                    request.AddParameter("application/json", "{\"AddedBy\":\"" + model + "\" ," +
                                     "\"ClientID\":" + model + "," +
                                     "\"TeamID\":" + model + "," +
                                     "\"FullName\":\"" + model.name + "\"," +
                                     "\"MemberEmail\":\"" + model.email + "\"," +
                                     "\"Phone\":\"" + model.Phone + "\"," +
                                     "\"JobTitle\":\"" + model.Jobtitle + "\"," +
                                     "\"TimeZoneID\":\"" + model.TimeZone + "\"," +
                                     "\"ProfileImageURL\":\"" + model + "\"," +
                                     "\"IsHOD\":\"" + model.HOD + "\"}", ParameterType.RequestBody);
                    IRestResponse response = client.Execute(request);
                    var Result1 = response.Content;
                    var json = JsonConvert.DeserializeObject<response_Addofficeteam>(Result1);
                    if (json.status == "Success")
                    {
                        return View("SuccessAddTeam", json);
                    }
                    else
                    {
                        return View();
                    }
                }
                catch (WebException wex)
                {
                    string StatusCode = ((HttpWebResponse)wex.Response).StatusCode.ToString();
                    string StatusDescription = ((HttpWebResponse)wex.Response).StatusDescription;
                    var error = "";
                    if (wex.Response != null)
                    {
                        using (var errorResponse = (HttpWebResponse)wex.Response)
                        {
                            using (var reader = new StreamReader(errorResponse.GetResponseStream()))
                            {
                                error = reader.ReadToEnd();
                                var msg = JsonConvert.DeserializeObject<Errormsg>(error);
                                var obj = msg.errors;
                                foreach (var jobj in obj)
                                {
                                    ViewBag.msg = jobj.ToString();
                                    return View();
                                }
                            }
                        }
                    }
                }
            }
            else
            {
                return View();
            }
            return View();
        }

        public IActionResult MemberConfirmation()
        {
            return View();
        }

        public IActionResult Edit_Member()
        {
            return View();
        }

        public IActionResult UpdateMember()
        {
            return View();
        }
        #endregion
        public IActionResult _partialview()
        {
            return View();
        }

        public IActionResult Profile()
        {
            return View();
        }


        [HttpPost]
        public IActionResult LoadMembers(OfficeTeamlist otl)
        {
            List<TeamMember> teammembers = otl.team_members;
            return PartialView("_PVMemberList", teammembers);
        }
    }
}