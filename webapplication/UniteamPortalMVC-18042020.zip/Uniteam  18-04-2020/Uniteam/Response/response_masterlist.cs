﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Uniteam.Response
{
    //public class JobTitleList
    //{
    //    public int jobTitleID { get; set; }
    //    public string jobTitle { get; set; }
    //}

    //public class CompanySizeList
    //{
    //    public int companySizeCategoryID { get; set; }
    //    public string companySize { get; set; }
    //}

    //public class IndustryList
    //{
    //    public int industryID { get; set; }
    //    public string industry { get; set; }
    //}

    //public class CountryList
    //{
    //    public int countryID { get; set; }
    //    public string country { get; set; }
    //}

    //public class response_masterlist
    //{
    //    public List<JobTitleList> jobTitleList { get; set; }
    //    public List<CompanySizeList> companySizeList { get; set; }
    //    public List<IndustryList> industryList { get; set; }
    //    public List<CountryList> countryList { get; set; }
    //}
}
