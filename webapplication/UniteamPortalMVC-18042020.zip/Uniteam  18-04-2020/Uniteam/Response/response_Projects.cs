﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Uniteam.Response
{
    public class response_Projects
    {
        public string status { get; set; }
        public string message { get; set; }
        public int clientID { get; set; }
        public string companyName { get; set; }
        public int totalProjects { get; set; }
        public string errors { get; set; }
    }
}
