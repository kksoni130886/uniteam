﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Uniteam.Response
{
    public class CallToAction
    {
        public string title { get; set; }
        public string subtitle { get; set; }
        public string activity_text { get; set; }
        public string activity { get; set; }
    }
    public class TodayTask
    {
        public int id { get; set; }
        public string task { get; set; }
        public string status { get; set; }
        public string type { get; set; }
        public int? office_teamid { get; set; }
        public string office_teamname { get; set; }
        public int? projectid { get; set; }
        public string project_name { get; set; }
        public int? taskid { get; set; }
    }
    public class Notice
    {
        public int id { get; set; }
        public string title { get; set; }
        public string date { get; set; }
        public string attachment { get; set; }
    }

    public class OfficeTeam
    {
        public int id { get; set; }
        public string name { get; set; }
        public string role { get; set; }
        public int total_members { get; set; }
    }

    public class Project
    {
        public int id { get; set; }
        public string name { get; set; }
        public int completion_percentage { get; set; }
        public int total_tasks { get; set; }
        public int total_members { get; set; }
    }
    public class Meeting
    {
        public int id { get; set; }
        public string name { get; set; }
        public string date { get; set; }
        public string timings { get; set; }
        public string venue { get; set; }
    }
    public class response_Home
    {
        public int userId { get; set; }
        public string fullName { get; set; }
        public string email { get; set; }
        public string usertype { get; set; }
        public string today_date { get; set; }
        public string today_day { get; set; }
        public int clientId { get; set; }
        public string companyName { get; set; }
        public List<CallToAction> call_to_actions { get; set; }
        public List<TodayTask> today_tasks { get; set; }
        public List<Notice> notices { get; set; }
        public List<OfficeTeam> office_teams { get; set; }
        public List<Project> projects { get; set; }
        public List<Meeting> meetings { get; set; }

        internal object ToPagedList(int v1, int v2)
        {
            throw new NotImplementedException();
        }
    }
}
