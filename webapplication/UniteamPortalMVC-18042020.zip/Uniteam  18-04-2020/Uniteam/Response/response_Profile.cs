﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Uniteam.Response
{

    public class Portal
    {
        public int clientID { get; set; }
        public string companyName { get; set; }
        public string role { get; set; }
    }

    public class response_Profile
    {
        public int userId { get; set; }
        public string fullName { get; set; }
        public string email { get; set; }
        public string signupMode { get; set; }
        public string userType { get; set; }
        public object jobTitle { get; set; }
        public string country { get; set; }
        public string photoUrl { get; set; }
        public string mobile { get; set; }
        public string companyCreated { get; set; }
        public string officeTeamAdded { get; set; }
        public string projectAdded { get; set; }
        public string signupFinished { get; set; }
        public string profileCompleted { get; set; }
        public DateTime registeredOn { get; set; }
        public List<Portal> portals { get; set; }
    }
}
