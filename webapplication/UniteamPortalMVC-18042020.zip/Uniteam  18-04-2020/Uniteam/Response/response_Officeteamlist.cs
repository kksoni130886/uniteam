﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Uniteam.Response
{
    public class TeamMember
    {
        public int memberid { get; set; }
        public object member_name { get; set; }
        public string email { get; set; }
        public object phone { get; set; }
        public object job_title { get; set; }
        public object time_zone { get; set; }
        public object profile_image { get; set; }
        public bool is_hod { get; set; }
    }
    public class OfficeTeamlist
    {
        public int teamid { get; set; }
        public string teamname { get; set; }
        public bool allow_editteam { get; set; }
        public bool allow_deleteteam { get; set; }
        public bool allow_addmember { get; set; }
        public bool allow_editmember { get; set; }
        public bool allow_deletemember { get; set; }
        public int total_members { get; set; }
        public List<TeamMember> team_members { get; set; }
    }
    public class response_Officeteamlist
    {
        public int userId { get; set; }
        public string fullName { get; set; }
        public string email { get; set; }
        public string userType { get; set; }
        public int clientId { get; set; }
        public bool allow_addteam { get; set; }
        public List<OfficeTeamlist> office_teams { get; set; }
        public List<response_memberlist> memberlist { get; set; }
    }
}
