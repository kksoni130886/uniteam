﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Uniteam.Response
{
    public class response_TeamSetting
    {
        public string Email { get; set; }
        public int ClientID { get; set; }
        public int TeamID { get; set; }
        public string TeamName { get; set; }
        public string Description { get; set; }
        public string TaskVisibility { get; set; }
        public bool Reminder { get; set; }
        public string ReminderTime { get; set; }
        public bool Digest { get; set; }
        public string DigestTime { get; set; }
    }
}
