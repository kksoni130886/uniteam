﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Uniteam.Response
{
    public class TeamMembers
    {
        public int memberid { get; set; }
        public string member_name { get; set; }
        public string email { get; set; }
        public string phone { get; set; }
        public string job_title { get; set; }
        public string time_zone { get; set; }
        public string profile_image { get; set; }
        public bool is_hod { get; set; }
    }

    public class response_memberlist
    {
        public int teamid { get; set; }
        public string teamname { get; set; }
        public bool allow_editteam { get; set; }
        public bool allow_deleteteam { get; set; }
        public bool allow_addmember { get; set; }
        public bool allow_editmember { get; set; }
        public bool allow_deletemember { get; set; }
        public int total_members { get; set; }
        public List<TeamMembers> team_members { get; set; }
    }
   
    
}
