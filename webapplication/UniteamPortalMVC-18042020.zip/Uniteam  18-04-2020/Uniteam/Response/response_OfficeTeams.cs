﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Uniteam.Response
{
    public class response_OfficeTeams
    {
        public string status { get; set; }
        public string message { get; set; }
        public int clientID { get; set; }
        public string companyName { get; set; }
        public int totalTeams { get; set; }
    }
}
