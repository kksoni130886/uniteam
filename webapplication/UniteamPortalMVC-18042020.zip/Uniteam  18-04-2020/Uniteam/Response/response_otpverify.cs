﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Uniteam.Response
{
    public class response_otpverify
    {
     public string status { get; set; }
     public string message {get;set;}
     public string emailId { get; set; }
     public string errors { get; set; }
}
}
